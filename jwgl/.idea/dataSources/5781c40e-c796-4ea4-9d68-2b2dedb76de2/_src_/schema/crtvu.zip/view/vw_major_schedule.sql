CREATE VIEW `vw_major_schedule` AS
  SELECT
    `crtvu`.`tb_target_major`.`open_id` AS `open_id`,
    `crtvu`.`tb_target_major`.`major`   AS `major`,
    `vw_schedule`.`id`                  AS `id`,
    `vw_schedule`.`teacher_id`          AS `teacher_id`,
    `vw_schedule`.`classroom`           AS `classroom`,
    `vw_schedule`.`class_name`          AS `class_name`,
    `vw_schedule`.`day`                 AS `day`,
    `vw_schedule`.`start_week`          AS `start_week`,
    `vw_schedule`.`end_week`            AS `end_week`,
    `vw_schedule`.`start_time`          AS `start_time`,
    `vw_schedule`.`end_time`            AS `end_time`,
    `vw_schedule`.`course_id`           AS `course_id`,
    `vw_schedule`.`school_year`         AS `school_year`,
    `vw_schedule`.`term`                AS `term`,
    `vw_schedule`.`people_num`          AS `people_num`,
    `vw_schedule`.`start_select_time`   AS `start_select_time`,
    `vw_schedule`.`end_select_time`     AS `end_select_time`,
    `vw_schedule`.`course_name`         AS `course_name`,
    `vw_schedule`.`credit`              AS `credit`,
    `vw_schedule`.`nature`              AS `nature`,
    `vw_schedule`.`department`          AS `department`
  FROM (`crtvu`.`tb_target_major`
    JOIN `crtvu`.`vw_schedule` ON ((`crtvu`.`tb_target_major`.`open_id` = `vw_schedule`.`open_id`)))