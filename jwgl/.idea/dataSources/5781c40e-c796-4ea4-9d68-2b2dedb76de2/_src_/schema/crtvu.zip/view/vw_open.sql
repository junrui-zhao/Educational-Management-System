CREATE VIEW `vw_open` AS
  SELECT
    `crtvu`.`tb_open`.`course_id`         AS `course_id`,
    `crtvu`.`tb_open`.`open_id`           AS `open_id`,
    `crtvu`.`tb_open`.`school_year`       AS `school_year`,
    `crtvu`.`tb_open`.`term`              AS `term`,
    `crtvu`.`tb_open`.`people_num`        AS `people_num`,
    `crtvu`.`tb_open`.`start_select_time` AS `start_select_time`,
    `crtvu`.`tb_open`.`end_select_time`   AS `end_select_time`,
    `crtvu`.`tb_course`.`course_name`     AS `course_name`,
    `crtvu`.`tb_course`.`credit`          AS `credit`,
    `crtvu`.`tb_course`.`nature`          AS `nature`,
    `crtvu`.`tb_course`.`department`      AS `department`
  FROM (`crtvu`.`tb_open`
    JOIN `crtvu`.`tb_course` ON ((`crtvu`.`tb_open`.`course_id` = `crtvu`.`tb_course`.`course_id`)))